package it.sauronsoftware.feed4j.bean;

/**
 * This interface is used to mark an object as a representation of a XML node.
 * 
 * @author Carlo Pelliccia
 */
public interface RawNode {
}
